# Конфигурация
BOT_TOKEN = "7364889190:AAGNoOSXH8RTbVCxOl0ztLOSuNhUDMGIhzE"
MAX_WARNINGS = 10  # Максимальное количество предупреждений перед баном
CLEANUP_INTERVAL = 3600  # Интервал очистки неактивных пользователей (в секундах)